declare module '@coreui/utils/src';

declare module '@coreui/chartjs/dist/js/coreui-chartjs.js';

declare module '*.json' {
  const value: any;
  export default value;
}

