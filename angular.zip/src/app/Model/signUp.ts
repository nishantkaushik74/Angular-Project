export class SignUpModel{
    Id:number=0;
    fullName:string='';
    email:string='';
    password:string='';
   userid:string='';
}