export interface Question {
    id: string;
    question: any;
    userid:string
  }