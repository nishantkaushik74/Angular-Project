export class SubjectModel{
    Id:number=0;
    subCode:string='';
    subName:string='';
}

