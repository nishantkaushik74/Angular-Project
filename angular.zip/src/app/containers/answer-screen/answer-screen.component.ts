import { Component } from '@angular/core';

@Component({
  selector: 'app-answer-screen',
  templateUrl: './answer-screen.component.html',
  styleUrls: ['./answer-screen.component.scss']
})
export class AnswerScreenComponent {

}
